
/**
 * Module dependencies.
 */

var express = require('express')
    , routes = require('./routes')
    , user = require('./routes/user')
    , admin = require('./routes/admin')
    , http = require('http')
    , path = require('path')
    , ejs = require('ejs')
    , url = require('url') ,
    sio = require('socket.io') ,
    MySQlSessionStore = require("connect-mysql-session")(express);

var app = express();
// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.engine('.html', ejs.__express);
app.set('view engine','ejs') ;
app.set('view engine', 'html');// app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(express.cookieParser());
app.use(express.cookieSession({secret : 'blog.fens.me'}));
app.use(express.session({
    secret : 'blog.fens.me',
    store: new MySQlSessionStore("cuihu_card","cuihu","15827712679"),
    cookie: { maxAge: 90000 } // expire session in 15 min or 900 seconds
}));
app.use(function(req, res, next){
    res.locals.user = req.session.user;
    var err = req.session.error;
    delete req.session.error;
    res.locals.message = '';
    if (err) res.locals.message = '<div class="alert alert-error">' + err + '</div>';
    var welcome="";
    var login_id= "" ;
    next();
});
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
    app.use(express.errorHandler());
}

//basic
//app.get('/', routes.index);
app.get('/', routes.login);
app.post('/', routes.doLogin);
app.get('/UserMain', routes.UserMain);
app.post('/UserMain', routes.UserMain);
app.get('/BusineMain',routes.BusineMain) ;
app.get('/AdminMain',routes.AdminMain) ;
app.post("/checkuser",routes.check);
app.get('/users', user.list);
app.get('/user/usecard',user.usecard) ;

app.get('/admin/showUser',admin.showUser) ;
app.get('/admin/addUser',admin.addUserView) ;
app.post('/admin/addUser',admin.addUser) ;
app.get('/admin/addMoney',admin.addMoneyView) ;
app.post('/admin/addMoney',admin.addMoney) ;
app.get('/admin/deleteUser',admin.deleteUser) ;
app.get('/admin/updateUser',admin.updateUserView) ;
app.post('/admin/updateUser',admin.updateUser) ;

app.get('/admin/showShop',admin.showShop) ;
app.get('/admin/updateShop',admin.updateShopView) ;
app.post('/admin/updateShop',admin.updateShop) ;
app.get('/admin/deleteShop',admin.deleteShop) ;
app.get('/admin/addShop',admin.addShopView) ;
app.post('/admin/addShop',admin.addShop) ;

app.get('/admin/showMac',admin.showMac) ;
app.get('/admin/addMac',admin.addMacView) ;
app.post('/admin/addMac',admin.addMac) ;
app.get('/admin/updateMac',admin.updateMacView) ;
app.post('/admin/updateMac',admin.updateMac) ;
app.get('/admin/deleteMac',admin.deleteMac) ;

app.get('/user/transportmoney', user.transportmoney);
app.post('/user/transportmoney', user.transport);
app.get('/admin/cardRecord', admin.showCard);
app.get('/user/cardRecord', user.showCard);

var nowThread = http.createServer(app).listen(app.get('port'), function(){
    console.log('Express server listening on port ' + app.get('port'));
});
    var NowMac={} ;
    var io = sio.listen(nowThread) ;
    var add = 0 ;
    io.sockets.on('connection' , function(socket){
        socket.on('addMac' ,function(mac_id){
            //name = ++add ;
            console.log(mac_id+'has start') ;
            NowMac[mac_id] =  1;
            socket.broadcast.emit('addMac' , mac_id) ;

        }) ;
        socket.on('deleteMac',function(mac_id){
            NowMac[mac_id] = 0 ;
            socket.broadcast.emit('deleteMac',mac_id) ;
        })
            socket.on('shopStartMac' , function(){
            socket.broadcast.emit('shopStartMac' ) ;

        });

    });
window.onload=function(){
	var socket = io.connect() ;
socket.on('connect' , function(){
	//send nickname by join event
	socket.emit('join' ,"cuihu") ;
	// show the message window
	//document.getElementById('chat').style.display='block' ;
	socket.on('announcement' ,function(msg){
		var li = document.createElement('li') ;
		li.className = 'announcement' ;
		li.innerHTML = msg ;
		document.getElementById('message').appendChild(li) ;
	});
});
}
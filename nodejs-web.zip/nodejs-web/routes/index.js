
/*
 * GET home page.
 */
var dbconfig = require('../config/db.config') ;
var db = require('../module/db') ;
exports.UserMain = function(req, res){
    console.log(req.session.user);

    if(!req.session.user){
        req.session.error='请先登录';
        res.redirect('/');
    }else{
        var allUser
        db.selectOneUserCard(req.session.user, function(allUser){
        res.render("user/index.ejs",{title:"index" ,allUser:allUser});
    });
    }

};
exports.AdminMain = function(req, res){
    console.log(req.session.user);

    if(!req.session.user){
        req.session.error='请先登录';
        res.redirect('/');
    }else{
        var allAdmin ;
        db.selectAllAdmin(function(allAdmin){
        res.render('admin/index.ejs', { title: 'index' ,allAdmin:allAdmin});
       }) ;
    }

};
exports.BusineMain = function(req, res){
    console.log(req.session.user);

    if(!req.session.user){
        req.session.error='请先登录';
        res.redirect('/');
    }else{
        var shop ;
        db.selectShop_mac(function(shop){
          res.render('busine/setMac', { title: 'index' ,shop:shop});    
        })
        
    }

};

exports.login = function(req,res){
    res.render("login1",{title:'login'});
};
exports.doLogin = function(req, res){
    var results ;
    db.CheckLogin(req , res, function(results){
    console.log(req.session.user) ;
    if(results == '0'){
        req.session.error = '用户名或密码不正确' ;
        res.redirect('/') ;
    }
    else if(results=='admin'){
        res.redirect('AdminMain') ;
    }
    else if(results=='shop'){
        res.redirect('BusineMain') ;
    }
    else if(results=='user'){
        res.redirect('UserMain') ;
    }
        }) ;


};
exports.check = function(req,res){
   // var queryObj = {userName: req.params.userName};
    console.log(req.body.userName+"--------------------------");
}
var dbconfig = require('../config/db.config') ;
var db = require('../module/db') ;
exports.showUser = function(req, res){
		var allUser ;
		db.selectAllUser(function(allUser){
	 	res.render("admin/showUser" ,{title:"showUser" , allUser:allUser} ) 
	 }) ;
}
exports.addUser = function(req,res){
	var addUserOption={
	   "user_name"  : req.body.AddUserName ,
	   "user_password" : req.body.UserPassword ,
	   "user_id" : req.body.UserID ,
	   "sex": req.body.DropDownTimezone,
	   "user_card_id" : req.body.UserCardId,
	   "card_money" : 0
	    } ;
	   db.addUser(addUserOption , function(){
	   	res.redirect("admin/showUser")
	   }) ;
}

exports.addUserView= function(req , res){
	res.render("admin/addUser") ;
}

exports.addMoney = function(req,res){
	var addMoneyOption={
	   "user_card_id"  : req.body.userId ,
	   "money" : req.body.money ,
	    } ;
	   var status ;
	   db.addMoney(addMoneyOption, function(status){
	   	if(status==1)res.redirect("admin/showUser")
	   	else if(status == 0 )res.redirect("admin/addMoneyError") ;
	   }) ;
}

exports.addMoneyView= function(req , res){
	res.render("admin/addMoney") ;
}

exports.deleteUser = function(req , res){
	  var url = require('url') ;
	  var queryObj = url.parse(req.url,true).query;  
	  console.log(queryObj);
      res.send(queryObj.callback+'(\'{"message": "test"}\')'); 
      //console.log(queryObj.choose)  ;
      db.deleteUser(queryObj.choose, function(){

      }) ;
  //res.send('_test(\'{"message": "test"}\')');     //对应jsonpCallback的函数 
}

exports.updateUser = function(req,res){
	console.log('updateUser') ;
	var userOption={
	   "user_id"  : req.body.user_Id ,
	   "user_name" : req.body.user_name ,
	   "user_card_id" : req.body.user_card_id,
	   "user_password":req.body.user_password ,
	   "user_card_money":req.body.user_card_money,
       "user_sex":req.body.user_sex
	    } ;
	   var status ;
	   db.updateUser(userOption , function(status){
	   	if(status==1)res.redirect("admin/showUser")
	   	else if(status == 0 ) ;
	   }) ;
}

exports.updateUserView= function(req , res){
	var results ;
	var url = require('url') ;
	db.selectOneUser(url.parse(req.url,true).query.choose,function(results){
	res.render("admin/updateUser" , {user:results}) ;	
	})
	
}
///////////////

exports.showShop = function(req, res){
		var allShop ;
		db.selectAllShop(function(allShop){
	 	res.render("admin/showShop" ,{title:"showShop" , allShop:allShop} ) 
	 }) ;
}

exports.updateShop = function(req,res){
	//console.log('updateUser') ;
	var shopOption={
	   "shop_id"  : req.body.shop_Id ,
	   "shop_name" : req.body.shop_name ,
	   "shop_password":req.body.shop_password ,
	    } ;
	   var status ;
	   db.updateShop(shopOption , function(status){
	   	if(status==1)res.redirect("admin/showShop") ;
	   	else if(status == 0 ) ;
	   }) ;
}

exports.updateShopView= function(req , res){
	var results ;
	var url = require('url') ;
	db.selectOneShop(url.parse(req.url,true).query.choose,function(results){
	res.render("admin/updateShop" , {shop:results}) ;	
	}) ;
}

exports.deleteShop = function(req , res){
	  var url = require('url') ;
	  var queryObj = url.parse(req.url,true).query;  
      res.send(queryObj.callback+'(\'{"message": "test"}\')'); 
      //console.log(queryObj.choose)  ;
      db.deleteShop(queryObj.choose, function(){

      }) ;
  //res.send('_test(\'{"message": "test"}\')');     //对应jsonpCallback的函数 
}

exports.addShop = function(req,res){
	var addShopOption={
	   "shop_name"  : req.body.AddShopName ,
	   "shop_password" : req.body.ShopPassword ,
	   "shop_id" : req.body.ShopID ,
	    } ;
	   db.addShop(addShopOption , function(){
	   	res.redirect("admin/showShop")
	   }) ;
}

exports.addShopView= function(req , res){
	res.render("admin/addShop") ;
}

exports.addMac = function(req,res){
	var addMacOption={
	   "mac_id"  : req.body.addMacID ,
	    } ;
	   db.addMac(addMacOption , function(){
	   	res.redirect("admin/showMac")
	   }) ;
}

exports.addMacView= function(req , res){
	res.render("admin/addMac") ;
}

exports.showMac = function(req, res){
		var allMac ;
		db.selectAllMac(function(allMac){
	 	res.render("admin/showMac" ,{title:"showMac" , allMac:allMac} ) 
	 }) ;
}

exports.updateMac = function(req,res){
	//console.log('updateUser') ;
	var MacOption={
	   "mac_id"  : req.body.Mac_Id ,
	   "shop_id" : req.body.Shop_Id ,
	    } ;
	   var status ;
	   db.updateMac(shopOption , function(status){
	   	if(status==1)res.redirect("admin/showMac") ;
	   	else if(status == 0 ) ;
	   }) ;
}

exports.updateMacView= function(req , res){
	var results ;
	var url = require('url') ;
	db.selectOneMac(url.parse(req.url,true).query.choose,function(results){
	res.render("admin/updateMac" , {mac:results}) ;	
	}) ;
}

exports.deleteMac = function(req , res){
	  var url = require('url') ;
	  var queryObj = url.parse(req.url,true).query;  
      res.send(queryObj.callback+'(\'{"message": "test"}\')'); 
      //console.log(queryObj.choose)  ;
      db.deleteMac(queryObj.choose, function(){

      }) ;
  //res.send('_test(\'{"message": "test"}\')');     //对应jsonpCallback的函数 
}

exports.showCard = function(req, res){
	var allUser ;
	db.selectAllRecord(function(allUser){
		console.log('############');
		console.log(allUser);
 	res.render("admin/cardRecord" ,{title:"showRecord" , allUser:allUser} ) ;
});
}

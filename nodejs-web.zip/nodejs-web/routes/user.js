var dbconfig = require('../config/db.config') ;
var db = require('../module/db') ;
/*
 * GET users listing.
 */

exports.transportmoney = function(req, res){
	res.render("user/transportmoney");
}
/////////////////////////////
exports.transport = function(req, res){
	db.transport(req.session.user, req.body.transport_card, req.body.transport_amount, function(){
		res.redirect("UserMain");
	});
/*console.log('#######################');
    console.log(req.body.transport_card);
    console.log(req.body.transport_amount);
    db.xiong(req.body.transport_card, req.body.transport_amount, function(){
    	res.redirect("UserMain");
    })*/
}

exports.list = function(req, res){
  res.send("respond with a resource");
};

exports.usecard=function(req,res){
 	res.render("user/useCard" ,{title:"usecard"}) ;
}

exports.showCard = function(req, res){
    var allUser ;
    db.selectAllRecord(function(allUser){
        console.log('############');
        console.log(allUser);
    res.render("user/cardRecord" ,{title:"showRecord" , allUser:allUser} ) ;
});
}

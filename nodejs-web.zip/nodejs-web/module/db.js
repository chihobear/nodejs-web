var mysql = require('mysql') ,
	dbconfig  = require('../config/db.config');
var db = mysql.createConnection(dbconfig) ;

exports.CheckLogin = function(req , res ,callback){
	//db.connect() ;
	db.query('SELECT 1 + 1 AS solution', function(err, rows, fields) {
    if (err) throw err;
    console.log('The solution is: ', rows[0].solution);
    });
    var user = req.body.username;
    var pwd = req.body.pwd;
    var results ;
    console.log(user+'  '+pwd) ;
    var selectSQL = "select * from admin_info where admin_name = '"+user+"' and admin_password = '"+pwd+"'";
    db.query(selectSQL,function (err, data) {
        if (err) console.log(err);
        if(data==""||data==null){
 			results = '0' ;
        }else{
        	results = 'admin' ;
            req.session.user = data[0].admin_name;
            welcome = data[0].admin_name;
            login_id=data[0].admin_id ;
            console.log('this is admin') ;
            //db.end() ;
            callback(results) ;
        }
    });
    selectSQL = "select * from user_card_money where user_card_id = '"+user+"' and user_password = '"+pwd+"'";
    db.query(selectSQL,function (err, data) {
        if (err) console.log(err);
        if(data==""||data==null){

        }else{
        	results = 'user' ;
            req.session.user = data[0].user_card_id;
            welcome = data[0].user_card_id;
            login_id=data[0].user_card_id ;
            //db.end() ;
            callback(results) ;//////////////////////////////////////////////////////////////////////////////////////
        }
    });
    selectSQL = "select * from shop_info where shop_name = '"+user+"' and shop_password = '"+pwd+"'";
    db.query(selectSQL,function (err, data) {
        if (err) console.log(err);
        if(data==""||data==null){

        }else{
            console.log('this is shop');
        	results = 'shop' ;
            req.session.user = data[0].shop_name;
            welcome = data[0].shop_name;
            //db.end() ;
            login_id=data[0].shop_id ;
            callback(results) ;
        }
    });
}

exports.selectAllAdmin = function(callback){
    selectSQL="select * from admin_info" ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log(err) ;
        callback(data) ;
    }) ;
    
}

exports.selectAllUser = function(callback){
    selectSQL=" select user_info.* ,user_card_money.* from user_card_money inner join user_info on user_info.user_id = user_card_money.user_id;" ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log(err) ;
        callback(data) ;
    }) ;
    
}

exports.selectAllShop = function(callback){
    selectSQL=" select * from shop_info" ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log(err) ;
        callback(data) ;
    }) ;
    
}

var judgeone = function(user, callback){
    insertSQL = "insert into user_card_money values( "+user.user_card_id+" ,"+user.card_money+" , "+user.user_id+"  , "+user.user_password+");"///////////写加号
    +"insert into user_info values("+user.user_id+" , '"+user.user_name+"', '"+user.sex+"');" ;
    db.query(insertSQL , function(err){
        if(err)console.log(err) ;
        callback() ;
    });
}
var judgetwo = function(user, callback){
    insertSQL = "insert into user_card_money values( "+user.user_card_id+" ,"+user.card_money+" , "+user.user_id+"  , "+user.user_password+");";
    db.query(insertSQL, function(err){
        if(err)console.log(err);
        callback();
    })
}

exports.addUser = function(user ,callback){
    selectSQL = "select user_id from user_card_money where user_id = '" +user.user_id+ "';";
    db.query(selectSQL, function(err, data){
        if(err)console.log(err);
        else if(data == ""|| data == null){
            judgeone(user, function(){
                callback();
            });
        }
        else{
            judgetwo(user, function(){
                callback();
            });
        }
    });
}

var sele = function(user, callback){
    updateSQL = "update user_card_money set card_money ="+user.money+" where user_card_id=" +user.user_card_id;
            db.query(updateSQL , function(err){
               if(err){
                callback(0);
               }
                else {
                   callback(1) ;
           }
        });
}

exports.addMoney = function(user, callback){
    selectSQL = "select card_money from user_card_money where user_card_id="+user.user_card_id;
    db.query(selectSQL, function(err,data){
        if(err)callback(0);
        else{
            var status;
            var a = parseInt(user.money) + parseInt(data[0].card_money);
            user.money = a;
            console.log(user.money);/////////////加上了原来值但是在修改语句里却没有更新
            sele(user, function(status){
                if(status == 0)callback(0);
                else{
                    callback(1);
                }
            });
        }
    });  
}

////////////////////
exports.deleteUser = function(user_card_id , callback){
    deleteSQL  = "delete from user_card_money where user_card_id = "+user_card_id ;
    db.query(deleteSQL,function(err){
        if(err)console.log('delet err') ;
        callback() ;
    })
}

exports.selectOneUser = function(user_card_id ,callback){
    var results ;
    selectSQL = "select user_info.user_name, user_info.sex ,user_card_money.* from user_card_money inner join user_info on user_info.user_id = user_card_money.user_id where user_card_id="+user_card_id;
    db.query(selectSQL ,function(err,data){
        if(err)console.log('select err') ;
        console.log(data[0]);
        callback(data[0]) ;
    });
}

exports.updateUser = function(user ,callback){
    //假想逻辑不修改id，这个修改麻烦些，不做
    updateSQL = "update user_info set user_name='"+user.user_name+"' ,sex = '"+user.user_sex+"' where user_id = '"+user.user_id+"';"+
                "update user_card_money set card_money='"+user.user_card_money+"',user_password='"+user.user_password+"';";
    db.query(updateSQL , function(err){
        if(err)callback(0) ;
        else {
            console.log('updateUser over') ;
            callback(1) ;
        }

    })

}

exports.selectOneShop = function(shop_id ,callback){
    var results ;
    selectSQL = "select * from shop_info where shop_id="+shop_id ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log('select err') ;
        callback(data[0]) ;
    })
}

exports.updateShop = function(user ,callback){
    //和上面逻辑一样，重复劳动
    updateSQL = "update shop_info set shop_name=? ,shop_password = ? where shop_id = ?";
    db.query(updateSQL ,[user.shop_name,user.shop_password ,user.shop_id], function(err){
        if(err)callback(0) ;
        else {
            console.log('updateShop over') ;
            callback(1) ;
        }

    })

}

exports.deleteShop = function(shop_id , callback){
    deleteSQL  = "delete from shop_info where shop_id = "+shop_id 
    + ";delete from shop_mac where shop_id="+shop_id ;
    db.query(deleteSQL,function(err){
        if(err)console.log('delet err') ;
        callback() ;
    })
}

exports.addShop = function(shop ,callback){
    insertSQL = "insert into shop_info values( "+shop.shop_id+" ,' "+shop.shop_name+" ' , ' " 
    +shop.shop_password+" ' );" ;
    db.query(insertSQL , function(err){
        if(err)console.log(err) ;
        callback() ;
    })

}

exports.selectAllMac = function(callback){
    selectSQL=" select mac_info.* ,shop_mac.shop_id from mac_info left join shop_mac on mac_info.mac_id = shop_mac.mac_id;" ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log(err) ;
        callback(data) ;
    }) ;
    
}

exports.addMac = function(mac ,callback){
    insertSQL = "insert into mac_info values(" + mac.mac_id+ " );" ;
    db.query(insertSQL , function(err){
        if(err)console.log(err) ;
        callback() ;
    })

}

exports.updateMac = function(mac ,callback){
    //和上面逻辑一样，重复劳动
    updateSQL = "update shop_mac set shop_id=?  where mac_id = ?";
    db.query(updateSQL ,[mac.shop_id , mac.mac_id], function(err){
        if(err)callback(0) ;
        else {
            console.log('updatemac over') ;
            callback(1) ;
        }

    })

}

exports.deleteMac = function(mac_id , callback){
    deleteSQL  = "delete from mac_info where mac_id = "+mac_id 
    + ";delete from shop_mac where mac_id="+mac_id ;
    db.query(deleteSQL,function(err){
        if(err)console.log('delet err') ;
        callback() ;
    })
}

exports.selectOneMac = function(mac_id ,callback){
    var results ;
    selectSQL = "select * from shop_mac where mac_id="+mac_id ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log('select err') ;
        if(data[0]==null){
            var da ={ "mac_id" : mac_id  , "shop_id" : 0} ;
            callback(da) ;

        }
        else callback(data[0]) ;
    })
}

exports.selectShop_mac=function( callback){
    var results ;
    selectSQL="select * from shop_mac where shop_id="+login_id ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log('select err')
            callback(data) ;
    });
}

exports.selectOneUserCard=function(user_card_id, callback){
    selectSQL="select user_info.user_name, user_info.sex ,user_card_money.* from user_card_money inner join user_info on user_info.user_id = user_card_money.user_id where user_card_id='"+user_card_id+"';";
    db.query(selectSQL, function(err, data){
        console.log(user_card_id);
         console.log(data);
        if(err)console.log('selectOneUserCard err');
            callback(data);
    });
}

/*var transportselect=function(user_card_id, callback){
    selectSQL="select card_money from user_card_money where card_id='"+user_card_id+"';";
    db.query(transportselect, function(err, data){
        if(err)console.log('transportselect err');
        callback(data);
    });
}

exports.transport=function(user_card_id_one, user_card_id_two, money, callback){
    var id_one;
    var id_two;
    var m;
    transportselect(user_card_id_one, function(data){
        id_one = data[0].card_money;
    });
    transportselect(user_card_id_one, function(data){
        id_two = data[0].card_money;
    });
    if(money > id_one){
        m = money;
        money+=id_two;
        id_two = id_one - m;
        updateSQLone="update user_card_money set card_money='"+money+"'where user_card_id='"+user_card_id_two+"';"+
                     "update user_card_money set card_money='"+id_two+"'where user_card_id='"+user_card_id_one+"';";
        db.query(updateSQLone,function(err){
            if(err)console.log("transport err");
            callback();
        });
    }
}
*/

var transportupdate=function(user_card_id_one, user_card_id_two, moneyone,moneytwo, callback){
    updateSQL="update user_card_money set card_money='"+moneyone+"'where user_card_id='"+user_card_id_one+"';"+
                     "update user_card_money set card_money='"+moneytwo+"'where user_card_id='"+user_card_id_two+"';";
    db.query(updateSQL, function(err){
        if(err)console.log('transportupdate err');
        callback();
    });
}

var transportselect=function(user_card_id,callback){
    selectSQL="select card_money from user_card_money where user_card_id='"+user_card_id+"';";
    db.query(selectSQL,function(err,data){
        if(err)console.log('transportselect err');
        callback(data);
    })
}

var insertconsumerecord=function(user_card_id_one, user_card_id_two, money,callback){
    insertSQL="insert into consume_record values('"+user_card_id_one+"','" +user_card_id_two+"','2016-12-15','"+money+"');";
    db.query(insertSQL,function(err){
        if(err)console.log('insertconsumerecord err');
        callback();
    }); 
}

exports.transport=function(user_card_id_one, user_card_id_two, money, callback){
    var m;
    var n;
    var j;
    selectSQL="select card_money from user_card_money where user_card_id='"+user_card_id_one+"';";
    db.query(selectSQL, function(err,data){
        if(err)console.log("transport err");
        console.log(user_card_id_one);
        console.log(data);
        m = data[0].card_money;
        console.log("m = "+m);
        n = m - money;
        console.log("n = "+n);
        transportselect(user_card_id_two,function(da){
            m = da[0].card_money;
            console.log("m = " + m);
            j = parseInt(m) + parseInt(money);                                     /////////////此处莫名原因将数据类型变成了字符串
            console.log("j="+j);
            transportupdate(user_card_id_one, user_card_id_two, n, j, function(){
                insertconsumerecord(user_card_id_one, user_card_id_two, money, function(){
                    callback();
                });
            })
        });
    });
}

exports.selectAllRecord=function(callback){
    selectSQL=" select consume_record.* from consume_record" ;
    db.query(selectSQL ,function(err,data){
        if(err)console.log(err) ;
        console.log(data);
        callback(data) ;
    }) ;
}
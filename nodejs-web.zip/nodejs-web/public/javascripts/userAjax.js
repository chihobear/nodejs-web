var socket = io.connect() ;
socket.on('addMac' , function(mac_id){
	var newTR = document.createElement('tr') ;
  newTR.className="success" ;
  newTR.setAttribute('class','success');
  newTR.setAttribute('id',mac_id);
  var newTD1   = document.createElement("td");
  var newText1 = document.createTextNode(mac_id);
  var newTD2   = document.createElement("td");
  var newText2 = document.createTextNode("4");
    var newTD3   = document.createElement("td");
  var newText3 = document.createTextNode("5");
  newTD1.appendChild(newText1);
  newTD2.appendChild(newText2);
  newTD3.appendChild(newText3);
  newTR.appendChild(newTD1);
  newTR.appendChild(newTD2);
  newTR.appendChild(newTD3);
  document.getElementById('ShowMac').appendChild(newTR);
  //alert(document.getElementById(mac_id).className) ;
}) ;

socket.on('deleteMac',function(mac_id){
	  var chooseRow= '' ;
	  var tb  = document.getElementById('showMac') ;
	  for(var i = 0 ; i<tb.length ; i++)
	  {
	  	if(tb.rows[i].cells[0]==mac_id){
	  		chooseRow = i ;
	  	}
	  }
	  alert(document.getElementById(mac_id).className) ;
	  tb.deleteRow(chooseRow) ;
	  //var table1=document.getElementByIdx_x('showMac');
     // table1.deleteRow(o.parentNode.parentNode.rowIndex);
})
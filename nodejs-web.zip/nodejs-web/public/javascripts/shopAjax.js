	var socket = io.connect() ;
function addMac(mac_id){
	//alert(mac_id) ;
	var button = document.getElementById(mac_id).value ;
	if(button==0){
		document.getElementById(mac_id).innerHTML='关闭刷卡器' ;
		document.getElementById(mac_id).value = 1 ;
		socket.emit('addMac' , mac_id) ;
	}
	else if(button==1)
	{
		document.getElementById(mac_id).innerHTML='开启刷卡器' ;
		document.getElementById(mac_id).value = 0 ;
		socket.emit('deleMac',mac_id) ;
	}
}